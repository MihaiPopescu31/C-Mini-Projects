#include <iostream>

#include <algorithm>

using namespace std;

int main() {
    int a, b, c;

    cout << "Introduceti valorile pentru a, b si c:\n";
    cout << "a = "; 
    cin >> a;
    cout << "b = ";
    cin >> b;
    cout << "c = ";
    cin >> c;

    cout << "Cele trei numere in ordine crescatoare: " << min({a, b, c}) << " " << a + b + c - min({a, b, c}) - max({a, b, c}) << " " << max({a, b, c}) << endl;
    cout << "Cele trei numere in ordine descrescatoare: " << max({a, b, c}) << " " << a + b + c - min({a, b, c}) - max({a, b, c}) << " " << min({a, b, c}) << endl;

    cout << "Cifrele pare din a: ";
    while (a) {
        if (a % 2 == 0) cout << a % 10 << " ";
        a /= 10;
    }

    cout << "\nCifrele impare din b: ";
    while (b) {
        if (b % 2 != 0) cout << b % 10 << " ";
        b /= 10;
    }

    cout << "\nSuma cifrelor impare din c: ";
    int sumaCifreImpare = 0;
    while (c) {
        sumaCifreImpare += (c % 2 != 0) ? c % 10 : 0;
        c /= 10;
    }
    cout << sumaCifreImpare << endl;

    return 0;
}