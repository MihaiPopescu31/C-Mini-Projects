#include <iostream>

using namespace std;

int main()
{

    int a,b;
    int max;
    cout<<"a=";
    cin>>a;
    cout<<"b=";
    cin>>b;

    if(a>b) cout<<"a este cel mai mare";
        else if(b>a) cout<<"b este cel mai mare";




    return 0;
}