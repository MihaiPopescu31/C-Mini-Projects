#include <iostream>
using namespace std;

int main(){
    
    int a,b;
    int maxim;
    
    cin>>a>>b;
    
    
    if(a > b)
    {
    maxim = a;
    }

    else
    { 
        maxim = b;
        
    }
    
    cout<<maxim<<endl;
    
    
    return 0;
}